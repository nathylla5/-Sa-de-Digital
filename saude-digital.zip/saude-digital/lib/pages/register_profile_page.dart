/*import 'package:flutter/material.dart';

class RegisterProfilePage extends StatefulWidget {
  const RegisterProfilePage({Key? key}) : super(key: key);

  @override
  State<RegisterProfilePage> createState() => _RegisterProfilePageState();
}

class _RegisterProfilePageState extends State<RegisterProfilePage> {
  const RadioExample({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          child: Column(children: [
            Image.asset('assets/Logo.png'),
            Text('Que perfil melhor se encaixa com você?'),
            
             
          ]),
        ),
      ),
    );
  }
}
*/